import meggy.Meggy;

class PA2Test1 {
	public static void main(String[] args) {
		Meggy.setPixel((byte) 7, (byte) 0, Meggy.Color.GREEN);
		Meggy.setPixel((byte) 5, (byte) 3, Meggy.Color.RED);
		/*** of course we accept comments ***/
		Meggy.setPixel((byte) 0, (byte) 6, Meggy.Color.DARK);
		Meggy.setPixel((byte) 3, (byte) 2, Meggy.Color.ORANGE);
		Meggy.setPixel((byte) 6, (byte) 4, Meggy.Color.YELLOW);
		Meggy.setPixel((byte) 2, (byte) 5, Meggy.Color.BLUE);
		Meggy.setPixel((byte) 4, (byte) 7, Meggy.Color.VIOLET);
		Meggy.setPixel((byte) 3, (byte) 0, Meggy.Color.WHITE);
		Meggy.setPixel((byte) 6, (byte) 0, Meggy.Color.VIOLET);
		Meggy.setPixel((byte) 1, (byte) 5, Meggy.Color.DARK);
	}
}
