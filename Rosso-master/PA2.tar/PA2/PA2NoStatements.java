import meggy.Meggy;

class PA2NoStatements {
	public static void main(String[] args) {
	}
}
